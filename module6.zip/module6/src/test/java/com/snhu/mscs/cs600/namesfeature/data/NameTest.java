package com.snhu.mscs.cs600.namesfeature.data;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

/**
 * NameTest
 *
 * Author: Malgorzata Debska
 * Purpose: Verifies that the generated email feature follows the required
 * firstname.lastname@example.com format.
 */
class NameTest {

    @Test
    void getEmailGeneratesRequiredFormat() {
        Name name = new Name();
        name.setFirst("Jane");
        name.setLast("Smith");

        assertEquals("jane.smith@example.com", name.getEmail());
    }

    @Test
    void getEmailTrimsExtraSpaces() {
        Name name = new Name();
        name.setFirst("  John ");
        name.setLast(" Doe  ");

        assertEquals("john.doe@example.com", name.getEmail());
    }
}
